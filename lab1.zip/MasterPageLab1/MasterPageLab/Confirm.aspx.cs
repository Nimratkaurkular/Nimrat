﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MasterPageLab
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            lblarrivaldate.Text = Session["value1"].ToString();
            lbldeparturedate.Text = Session["value2"].ToString();
            lblpeople.Text = Session["value3"].ToString();
            lblbedtype.Text = Session["value4"].ToString();
            lblspecialmote.Text = Session["value5"].ToString();
            lblfullname.Text = Session["value6"].ToString() + Session["value7"].ToString();
            lblemail.Text = Session["value8"].ToString();
            lblnumber.Text = Session["value9"].ToString();
            lblpayment.Text = Session["value10"].ToString();
            
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Label1.Text = "Thank You For Your Request.";
            Label2.Text = "We will get back to you within 24 Hours.";
        }

    }
}